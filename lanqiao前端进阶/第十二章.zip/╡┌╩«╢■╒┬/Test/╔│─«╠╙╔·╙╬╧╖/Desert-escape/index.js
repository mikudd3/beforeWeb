let equip = {
    // 水
    water:{
        name:"水",
        describe:"有助于减少身体脱水的速度"
    },
    // 手电筒
    torch:{
        name:"手电筒",
        describe:"可用来作为发送信号的工具"
    },
    // 镜子
    mirror:{
        name:"镜子",
        describe:"可用来表示你的位置"
    },
    // 降落伞
    parachute:{
        name:"降落伞",
        describe:"用来遮荫和发送信号",
    },
    // 太阳镜
    sunglasses:{
        name:"太阳镜",
        describe:"用来防止眼睛被太阳灼伤",
        color:["黑色","粉色","蓝色"]
    }
}

console.log('小蓝选择的是' + equip.mirror.name + '它的作用是'+equip.mirror.describe);
console.log('小白选择的是' + equip.sunglasses.name + '它的作用是'+equip.sunglasses.describe);



