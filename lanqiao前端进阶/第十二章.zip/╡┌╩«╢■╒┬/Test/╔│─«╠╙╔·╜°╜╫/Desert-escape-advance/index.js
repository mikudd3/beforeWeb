let equip = {
    // 水
    water: {
        name: "水",
        describe: "有助于减少身体脱水的速度",
        price: 20,
        explain: "水是 20 元一瓶"
    },
    // 手电筒
    torch: {
        name: "手电筒",
        describe: "可用来作为发送信号的工具",
        price: 30,
        explain: "手电筒是 30 元一个，太阳能充电"
    },
    // 镜子
    mirror: {
        name: "镜子",
        describe: "可用来表示你的位置",
        price: 15,
        explain: "镜子是 15 元一个"
    },
    // 降落伞
    parachute: {
        name: "降落伞",
        describe: "用来遮荫和发送信号",
        price: 80,
        explain: "降落伞是 90 元一个"
    },
    // 太阳镜
    sunglasses: {
        name: "太阳镜",
        describe: "用来防止眼睛被太阳灼伤",
        color: ["黑色", "粉色", "蓝色"],
        price: 40,
        explain: "太阳镜无论颜色，都是 40 元一个"
    }
}
// 定义一个名为 MaxPrice 的常量，用来设置现金最大值为 200 元。
const MaxPrice = 200
// 使用解构赋值的方法取出各个装备的价格，并存放在一个名为 arr 的数组中。
const { water, torch, mirror, parachute, sunglasses } = equip;
const arr = [water.price, torch.price, mirror.price, parachute.price, sunglasses.price];
// console.log(arr); // [20, 30, 15, 80, 40]
// 请你自行选择一些装备，然后计算其总金额。
const totalPrice = water.price + sunglasses.price;

if (totalPrice <= MaxPrice) {
    console.log('恭喜你，购买成功');
} else {
    console.log('你的余额不足，购买失败');
}
