(function ($) {
    $.fn.extend({
        color: function (color = "red") {
            $(this).css('color', color)
        },
    });
})(jQuery);