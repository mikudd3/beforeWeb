; (function () {
  $.fn.extend({
    changeTableColor: function () {

      $(this).find("tr:not(:first-child)").filter(':odd').addClass("odd"); //先排除第一行,然后给奇数行添加样式
      $(this).find("tr:not(:first-child)").filter(':even').addClass("even"); //先排除第一行,然后给偶数行添加样式

      $(this).find("tr:first-child").css('background-color', '#fff'); // 第一行背景白色
    }
  });
})(jQuery);