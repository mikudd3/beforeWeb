package com.servlet;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //一. 获取客户要查询的关键字
        String keyWord = request.getParameter("keyWord");
        System.out.println(keyWord);

        //2. 去目标数组中找所有包含关键字的字符串，加入到集合中
        String[] arr = {"ActionScript","AppleScript","Asp","BASIC","C","C++","Clojure","COBOL","ColdFusion","Erlang","Fortran","Groovy", "Haskell", "Java", "JavaScript", "Lisp", "Perl", "PHP", "Python", "Ruby", "Scala", "Scheme"};

        List<String> resultList = new ArrayList<String>();


        for(String str: arr) {

            int place = str.toLowerCase().indexOf(keyWord.toLowerCase());
            if (place != -1) { // 找到了
                resultList.add(str);
            }
        }

        System.out.println(resultList);


        //3. 把查询结果输出给用户
        /* 在这里补全代码，使用谷歌的 gson 工具把 resultList 转换为 json对象*/
        // 使用谷歌的 gson 工具把 resultList 转换为 json 对象
        Gson gson = new Gson();
        String searchResultJson = gson.toJson(resultList);

        // 以 json 格式响应给客户端
        response.setContentType("application/json; charset=utf-8");

		
        /*在这里补全代码 以 json 格式响应给客户端*/
        PrintWriter out = response.getWriter();
		out.println(searchResultJson);
        out.flush();
        out.close();
    }


}
