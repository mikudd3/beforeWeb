(function ($) {
  // 自定义类级别插件
  $.extend({
    multiple: function (a, b) {
      return a * b;
    },
  });
})(jQuery);