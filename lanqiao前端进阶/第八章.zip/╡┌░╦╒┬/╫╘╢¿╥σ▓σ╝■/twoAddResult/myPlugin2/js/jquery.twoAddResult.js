(function ($) {
    // 自定义类级别插件
    $.extend({
      sum: function (a, b) {
        return a + b;
      },
    });
  })(jQuery);