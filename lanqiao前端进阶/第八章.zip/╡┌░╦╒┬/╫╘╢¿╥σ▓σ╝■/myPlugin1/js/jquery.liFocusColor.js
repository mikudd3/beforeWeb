(function ($) {
    // 自定义对象级别插件-----liFocusColor
    // 需求: 给指定 ul 中的 li 设置鼠标悬浮的背景颜色，如果没传入参数 默认颜色为 yellowgreen
    $.fn.extend({
        liFocusColor: function (color = "yellowgreen") {
            var $liObj = $(this).find("li");

            $liObj.each(function () {
                $(this)
                    .on("mouseover", function () {
                        $(this).css("background-color", color);
                    })
                    .on("mouseout", function () {
                        $(this).css("background-color", "#fff");
                    });
            });
        },
    });
})(jQuery);