"use strict";
let p = {
    name: 'jack',
    age: 18
};
